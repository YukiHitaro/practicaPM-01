﻿using System;
using System.Collections.Generic;
using System.Windows;

namespace Sklad
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            WarehouseManager manager = new WarehouseManager();

            // Пример данных
            List<WarehouseItem> warehouse1 = new List<WarehouseItem>
            {
                new WarehouseItem { Name = "Item1", Category = "Electronics", Quantity = 10, Price = 50 },
                new WarehouseItem { Name = "Item2", Category = "Clothing", Quantity = 5, Price = 30 }
            };

            List<WarehouseItem> warehouse2 = new List<WarehouseItem>
            {
                new WarehouseItem { Name = "Item1", Category = "Electronics", Quantity = 15, Price = 50 },
                new WarehouseItem { Name = "Item3", Category = "Food", Quantity = 20, Price = 20 }
            };

            List<List<WarehouseItem>> warehouses = new List<List<WarehouseItem>> { warehouse1, warehouse2 };

            // Подсчет количества товаров
            int totalItems = manager.CountItems(warehouses);
            int warehouse1Items = manager.CountItems(warehouse1);

            // Подсчет суммы стоимости товаров
            decimal totalCost = manager.CalculateTotalCost(warehouses);
            decimal warehouse1Cost = manager.CalculateTotalCost(warehouse1);

            // Подсчет товаров по категориям
            var categoryCount = manager.CountItemsByCategory(warehouses);

            // Вывод результатов
            ResultTextBox.Text = $"Total Items: {totalItems}\nWarehouse 1 Items: {warehouse1Items}\nTotal Cost: {totalCost}\nWarehouse 1 Cost: {warehouse1Cost}\nCategory Count:\n";
            foreach (var category in categoryCount)
            {
                ResultTextBox.Text += $"{category.Key}: {category.Value}\n";
            }
        }
    }
}