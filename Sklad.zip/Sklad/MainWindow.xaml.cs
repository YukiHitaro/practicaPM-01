﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows;

namespace Sklad
{
    public partial class MainWindow : Window
    {
        private readonly WarehouseManager _warehouseManager;

        public MainWindow()
        {
            InitializeComponent();
            _warehouseManager = new WarehouseManager(new HttpClient());
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            string apiUrl = "https://api.example.com/warehouse";

            try
            {
                List<WarehouseItem> warehouseItems = await _warehouseManager.GetWarehouseItemsAsync(apiUrl);

                // Подсчет количества товаров
                int totalItems = _warehouseManager.CountItems(new List<List<WarehouseItem>> { warehouseItems });

                // Подсчет суммы стоимости товаров
                decimal totalCost = _warehouseManager.CalculateTotalCost(new List<List<WarehouseItem>> { warehouseItems });

                // Подсчет товаров по категориям
                var categoryCount = _warehouseManager.CountItemsByCategory(new List<List<WarehouseItem>> { warehouseItems });

                // Вывод результатов
                ResultTextBox.Text = $"Total Items: {totalItems}\nTotal Cost: {totalCost}\nCategory Count:\n";
                foreach (var category in categoryCount)
                {
                    ResultTextBox.Text += $"{category.Key}: {category.Value}\n";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }
    }
}