﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Sklad
{
    public class WarehouseManager
    {
        private readonly HttpClient _httpClient;

        public WarehouseManager(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<List<WarehouseItem>> GetWarehouseItemsAsync(string apiUrl)
        {
            var response = await _httpClient.GetAsync(apiUrl);
            response.EnsureSuccessStatusCode();

            var content = await response.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<List<WarehouseItem>>(content);
        }

        public int CountItems(List<WarehouseItem> items)
        {
            return items.Sum(item => item.Quantity);
        }

        public int CountItems(List<List<WarehouseItem>> warehouses)
        {
            return warehouses.SelectMany(warehouse => warehouse).Sum(item => item.Quantity);
        }

        public decimal CalculateTotalCost(List<WarehouseItem> items)
        {
            return items.Sum(item => item.Quantity * item.Price);
        }

        public decimal CalculateTotalCost(List<List<WarehouseItem>> warehouses)
        {
            return warehouses.SelectMany(warehouse => warehouse).Sum(item => item.Quantity * item.Price);
        }

        public Dictionary<string, int> CountItemsByCategory(List<WarehouseItem> items)
        {
            return items.GroupBy(item => item.Category)
                        .ToDictionary(group => group.Key, group => group.Sum(item => item.Quantity));
        }

        public Dictionary<string, int> CountItemsByCategory(List<List<WarehouseItem>> warehouses)
        {
            return warehouses.SelectMany(warehouse => warehouse)
                             .GroupBy(item => item.Category)
                             .ToDictionary(group => group.Key, group => group.Sum(item => item.Quantity));
        }
    }

    public class WarehouseItem
    {
        public string Name { get; set; }
        public string Category { get; set; }
        public int Quantity { get; set; }
        public decimal Price { get; set; }
    }
}